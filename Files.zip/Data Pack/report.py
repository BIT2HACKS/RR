from pathlib import Path
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image

# Edit these before submission
AUTHOR = "Ujjal Ray"
DATE = "15th November 2026"

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
CHARTS = OUT / "charts"
OUT.mkdir(exist_ok=True)
CHARTS.mkdir(exist_ok=True)
PDF = OUT / "UJJAL RAY_SupeRR_Methodology_Report.pdf"

BATTERS = [
[1,"Sameer Rizvi","T20",10,191,172.77,92.16,80.62],
[2,"Reeza Hendricks","T20I",12,245,183.27,131.36,51.91],
[3,"Mohammad Nabi","T20I",26,317,153.63,107.94,45.69],
[4,"Babar Azam","T20I",13,155,169.03,127.78,41.25],
[5,"Fakhar Zaman","T20I",14,169,160.36,124.35,36.00],
[6,"Towhid Hridoy","T20I",21,389,139.59,116.02,23.57],
[7,"Sikandar Raza","T20I",26,369,156.10,120.72,35.37],
[8,"Anuj Rawat","T20",9,115,140.87,101.23,39.63],
[9,"Jimmy Neesham","T20I",18,172,159.30,118.47,40.83],
[10,"Mark Chapman","T20I",22,340,159.71,134.52,25.18],
]
BOWLERS = [
[1,"Mohit Sharma","T20",23,326,8.87,10.42,10.12],
[2,"Gudakesh Motie","T20I",20,283,7.14,8.90,7.07],
[3,"Mohammad Nawaz","T20I",29,337,6.43,7.48,9.50],
[4,"Jamie Overton","T20, T20I",15,162,6.44,9.74,10.49],
[5,"Umran Malik","T20, T20I",13,173,8.60,10.40,10.98],
[6,"Krunal Pandya","T20",31,422,7.42,8.01,6.40],
[7,"Jimmy Neesham","T20I",15,168,8.43,9.28,10.12],
[8,"Barry McCarthy","T20I",18,191,7.95,9.00,7.85],
[9,"Zakary Foulkes","T20I",10,123,8.05,10.13,8.13],
[10,"Jofra Archer","T20, T20I",29,253,7.57,9.41,9.09],
]

# Charts are generated from the final ranking table values above.
def chart_comparison(rows, pressure_col, normal_col, xlabel, filename):
    names = [r[1] for r in rows]
    p = [r[pressure_col] for r in rows]
    n = [r[normal_col] for r in rows]
    y = list(range(len(names)))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    h = 0.36
    ax.barh([v-h/2 for v in y], p, h, label="Pressure")
    ax.barh([v+h/2 for v in y], n, h, label="Normal")
    ax.set_yticks(y, names)
    ax.invert_yaxis()
    ax.set_xlabel(xlabel)
    ax.legend(frameon=False)
    ax.grid(axis="x", alpha=.25)
    ax.set_axisbelow(True)
    ax.spines[["top","right"]].set_visible(False)
    fig.tight_layout()
    dest = CHARTS / filename
    fig.savefig(dest, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return dest

batter_chart = chart_comparison(BATTERS, 5, 6, "Strike rate", "batters.png")
bowler_chart = chart_comparison(BOWLERS, 5, 6, "Runs conceded per over", "bowlers.png")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="Cover", parent=styles["Title"], fontSize=24, leading=30,
                          textColor=colors.HexColor("#17324D"), alignment=0, spaceAfter=12))
styles.add(ParagraphStyle(name="H1x", parent=styles["Heading1"], fontSize=15, leading=19,
                          textColor=colors.HexColor("#17324D"), spaceBefore=12, spaceAfter=7))
styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontSize=11, leading=14,
                          textColor=colors.HexColor("#28658A"), spaceBefore=8, spaceAfter=5))
styles.add(ParagraphStyle(name="Bodyx", parent=styles["BodyText"], fontSize=9, leading=13,
                          textColor=colors.HexColor("#26323A"), spaceAfter=6))
styles.add(ParagraphStyle(name="Eq", parent=styles["BodyText"], fontSize=9, leading=14,
                          alignment=1, backColor=colors.HexColor("#EAF1F6"),
                          borderPadding=7, spaceBefore=3, spaceAfter=7))
styles.add(ParagraphStyle(name="Note", parent=styles["BodyText"], fontSize=8, leading=11,
                          textColor=colors.HexColor("#5B6770"), spaceAfter=5))

def P(s, style="Bodyx"):
    return Paragraph(s, styles[style])

def tbl(data, widths, size=7):
    t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17324D")),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),
        ("FONTSIZE",(0,0),(-1,-1),size),
        ("GRID",(0,0),(-1,-1),.35,colors.HexColor("#D8DEE4")),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F4F6F8")]),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("LEFTPADDING",(0,0),(-1,-1),4),
        ("RIGHTPADDING",(0,0),(-1,-1),4),
        ("TOPPADDING",(0,0),(-1,-1),5),
        ("BOTTOMPADDING",(0,0),(-1,-1),5),
    ]))
    return t

def footer(canvas, doc):
    canvas.saveState()
    w,h = A4
    canvas.setStrokeColor(colors.HexColor("#D8DEE4"))
    canvas.line(18*mm,15*mm,w-18*mm,15*mm)
    canvas.setFont("Helvetica",8)
    canvas.setFillColor(colors.HexColor("#5B6770"))
    canvas.drawString(18*mm,10*mm,"SupeRR Selector Season 2 | Round 1")
    canvas.drawRightString(w-18*mm,10*mm,f"Page {doc.page}")
    canvas.restoreState()

story = []
story += [
    Spacer(1,25*mm), P("SUPERR SELECTOR SEASON 2 | ROUND 1","Note"),
    P("Identifying the Most Reliable<br/>Players Under Pressure","Cover"),
    P("Methodology and Results Report","H2x"), Spacer(1,15*mm),
    tbl([["Prepared by",AUTHOR],["Submission date",DATE],
         ["Formats", "T20 and T20I"],["Data period","2022 onwards"]],
        [42*mm,110*mm],8),
    Spacer(1,15*mm),
    P("This report describes the analysis carried out on the supplied ball-by-ball dataset, the pressure measures used, the player-rating method, and the resulting rankings."),
    PageBreak()
]

story += [
P("1. Summary","H1x"),
P("We compared each player's performance in difficult match situations with that player's performance in normal situations. A pressure score was calculated at delivery level. Batting and bowling were evaluated separately, and players were ranked using their improvement under pressure, adjusted for the amount of available evidence."),
P("The highest-ranked batter in the baseline model is Sameer Rizvi. The highest-ranked bowler is Mohit Sharma."),
P("2. Dataset and scope","H1x"),
P("The supplied ball-by-ball file contains 200,999 deliveries. The match file contains 883 matches: 482 T20I and 401 T20. Supporting files include competitions (141 records), playing XI (28,381 records), competition-team-player mappings (6,413 records), and teams (353 records)."),
P("Sixteen matches had no ball-by-ball records and were not usable for delivery-level calculations. The main analysis used regular first and second innings. Super Overs were excluded from the main player calculations because they represent a different match situation and have very few observations."),
P("3. Defining pressure","H1x"),
P("We treated pressure differently in the two innings. During a chase, the required run rate is a direct measure of the scoring demand. In the first innings, there is no target to chase, so we compared the current score with the expected score for that format at the same legal-ball position."),
P("3.1 Second-innings pressure","H2x"),
P("RRR = (Runs required × 6) / Legal balls remaining","Eq"),
P("P_RRR = min(max(RRR, 0), 18) / 18<br/>P_Stage = 1 − (Legal balls remaining / Innings ball limit)<br/>P_Wicket = 1 − (Wickets remaining / 10)","Eq"),
P("Chase pressure = 100 × (0.50 × P_RRR + 0.25 × P_Stage + 0.25 × P_Wicket)","Eq"),
P("The required run rate is capped at 18 before normalisation. This prevents a few extreme final-ball situations from dominating the scale."),
P("3.2 First-innings pressure","H2x"),
P("Expected first-innings scores were calculated separately for T20 and T20I at each legal-ball position. The score-deficit component is based on how far the current score is below that expected score."),
P("P_Score = min(Score deficit / max(Expected score, 20), 1)<br/>P_Wicket = Wickets lost / 10<br/>P_Stage = Legal balls bowled / Innings ball limit","Eq"),
P("First-innings pressure = 100 × (0.50 × P_Score + 0.25 × P_Wicket + 0.25 × P_Stage)","Eq"),
P("Scores below 40 were labelled low pressure, 40 to below 65 medium pressure, and 65 or above high pressure. For player comparisons, scores of 40 or above were treated as pressure. Deliveries after the chasing team had reached the target were excluded from active chase pressure."),
P("The first-innings and chase scores are not identical measures: one uses performance relative to par, while the other uses required run rate. This is a limitation to keep in mind when interpreting the results.","Note"),
P("4. Performance measures","H1x"),
P("4.1 Batting","H2x"),
tbl([["Metric","Calculation","Desired direction"],
     ["Strike rate","Runs / balls faced × 100","Higher"],
     ["Dismissal rate","Dismissals / balls faced × 100","Lower"],
     ["Dot-ball rate","Dot balls / balls faced × 100","Lower"],
     ["Boundary rate","Boundaries / balls faced × 100","Higher"]],
    [35*mm,82*mm,35*mm],7),
P("Wides were excluded from balls faced. A batter dismissal was counted when the dismissed-player identifier matched the striker. Metrics were calculated separately for pressure and normal deliveries."),
P("4.2 Bowling","H2x"),
tbl([["Metric","Calculation","Desired direction"],
     ["Economy","Runs conceded × 6 / legal balls","Lower"],
     ["Wicket rate","Bowler wickets / legal balls × 100","Higher"],
     ["Dot-ball rate","Dot balls / legal balls × 100","Higher"]],
    [35*mm,82*mm,35*mm],7),
P("Caught, bowled, LBW, stumped, and hit-wicket dismissals were credited to the bowler. Run-outs and other dismissals not credited to the bowler were excluded. Byes and leg-byes were excluded from bowler runs conceded."),
P("5. Eligibility and reliability","H1x"),
tbl([["Condition","Batters","Bowlers"],
     ["Pressure exposure","30 balls","30 legal balls"],
     ["Pressure matches","3","3"],
     ["Normal exposure","60 balls","60 legal balls"],
     ["Normal matches","5","5"],
     ["Final evidence filter","100 pressure balls; 8 matches","120 pressure legal balls; 8 matches"]],
    [48*mm,52*mm,52*mm],7),
P("A reliability multiplier reduced the influence of players with limited exposure. For batters:","Bodyx"),
P("R = √[(Bp/(Bp+100)) × (Bn/(Bn+150)) × (Mp/(Mp+5)) × (Mn/(Mn+5))]","Eq"),
P("Bp and Bn are pressure and normal balls faced; Mp and Mn are pressure and normal matches. For bowlers, legal balls bowled replace balls faced. This is a heuristic exposure adjustment, not a statistical confidence interval."),
P("6. Rating method","H1x"),
P("Each improvement metric was converted to a z-score among eligible players within the same format. Z-scores were clipped to the range −2.5 to +2.5."),
P("6.1 Batter score","H2x"),
P("SR improvement = Pressure SR − Normal SR<br/>Dismissal improvement = Normal dismissal rate − Pressure dismissal rate<br/>Dot improvement = Normal dot rate − Pressure dot rate<br/>Boundary improvement = Pressure boundary rate − Normal boundary rate","Eq"),
P("Raw batting score = 0.40 × Z(SR improvement) + 0.20 × Z(Dismissal improvement) + 0.20 × Z(Dot improvement) + 0.20 × Z(Boundary improvement)","Eq"),
P("Final batting score = Raw batting score × Reliability","Eq"),
P("6.2 Bowler score","H2x"),
P("Economy improvement = Normal economy − Pressure economy<br/>Wicket improvement = Pressure wicket rate − Normal wicket rate<br/>Dot improvement = Pressure dot rate − Normal dot rate","Eq"),
P("Raw bowling score = 0.40 × Z(Economy improvement) + 0.30 × Z(Wicket improvement) + 0.30 × Z(Dot improvement)","Eq"),
P("Final bowling score = Raw bowling score × Reliability","Eq"),
P("T20 and T20I were standardised separately. If a player qualified in both formats, the overall score was the mean of the two format-specific scores. If a player qualified in one format, that score was used."),
PageBreak(),
P("7. Top 10 batters","H1x")
]

bdata = [["Rank","Player","Format","P matches","P balls","Pressure SR","Normal SR","Change"]]
for r in BATTERS:
    bdata.append([str(r[0]),r[1],r[2],str(r[3]),str(r[4]),f"{r[5]:.2f}",f"{r[6]:.2f}",f"{r[7]:.2f}"])
story += [tbl(bdata,[9*mm,33*mm,18*mm,17*mm,15*mm,19*mm,18*mm,18*mm],6.5),
          Spacer(1,4*mm),P("The chart compares pressure and normal strike rates. The final ranking also uses dismissal rate, dot-ball rate, boundary rate, and reliability."),
          Image(str(batter_chart),width=165*mm,height=92*mm),
          P("8. Top 10 bowlers","H1x")]

wdata = [["Rank","Player","Format","P matches","P balls","Pressure econ.","Normal econ.","Wkts/100"]]
for r in BOWLERS:
    wdata.append([str(r[0]),r[1],r[2],str(r[3]),str(r[4]),f"{r[5]:.2f}",f"{r[6]:.2f}",f"{r[7]:.2f}"])
story += [tbl(wdata,[9*mm,33*mm,23*mm,17*mm,15*mm,18*mm,18*mm,17*mm],6.5),
          Spacer(1,4*mm),P("The chart compares pressure and normal economy. Lower economy is better. Wicket rate and dot-ball rate also contribute to the final score."),
          Image(str(bowler_chart),width=165*mm,height=92*mm),
          PageBreak(),P("9. Sensitivity analysis","H1x"),
          P("We changed the metric weights while keeping the rest of the ranking process unchanged. This tests whether the selected top 10 depends heavily on one particular set of weights."),
          tbl([["Role","Baseline vs Alternative 1","Baseline vs Alternative 2"],
               ["Batters","9 of 10 common","10 of 10 common"],
               ["Bowlers","8 of 10 common","8 of 10 common"]],
              [40*mm,55*mm,55*mm],8),
          P("For batting, Alternative 1 brought George Dockrell into the top 10 and moved Jimmy Neesham out. Alternative 2 retained all ten baseline batters. For bowling, both alternatives retained eight of the ten baseline players; the changes were among the lower-ranked candidates."),
          P("We retained the baseline weights: 40/20/20/20 for batting and 40/30/30 for bowling. The alternatives are robustness checks, not replacement rankings."),
          P("10. Limitations","H1x")]

for item in [
"First-innings and chase pressure are calculated differently because the available match-state information differs.",
"The pressure-component weights and metric weights are choices made for this analysis; other reasonable choices may produce different rankings.",
"The reliability multiplier and minimum exposure requirements reduce, but do not remove, small-sample uncertainty.",
"Format-specific standardisation helps compare T20 and T20I players, but does not control for every difference in competition conditions or player roles.",
"Batting position, opposition strength, venue, pitch conditions, and bowling phase are not fully adjusted for in this version.",
"Some extra-delivery categories required classification assumptions when deriving legal balls and bowler runs conceded. These assumptions should be documented and applied consistently.",
"The score measures relative improvement in this dataset under this method. It is not a guarantee of future performance or a universal measure of player quality."
]:
    story.append(P("• " + item))

story += [
P("11. Conclusion","H1x"),
P("This analysis compares player performance under pressure with their performance in normal situations. It uses delivery-level match context, separate batting and bowling metrics, format-specific standardisation, and an exposure-based reliability adjustment."),
P("Under the baseline method, Sameer Rizvi is the highest-ranked batter and Mohit Sharma is the highest-ranked bowler. The batting top 10 is stable under the tested alternative weights. The bowling top 10 is reasonably stable, but more sensitive to the weighting of economy, wickets, and dot balls."),
P("The analysis can be reproduced using the supplied CSV files and the pressure definitions, eligibility rules, scoring equations, and weights documented here."),
]

doc = SimpleDocTemplate(str(PDF), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm,
                        topMargin=17*mm, bottomMargin=21*mm,
                        title="Identifying the Most Reliable Players Under Pressure",
                        author=AUTHOR)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(f"Created: {PDF}")
